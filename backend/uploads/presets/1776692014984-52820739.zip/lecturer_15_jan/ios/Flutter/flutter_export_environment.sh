#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=D:\flutter_windows_3.35.4-stable\flutter"
export "FLUTTER_APPLICATION_PATH=D:\LYCEE DE NYANZA\MY OFFICE\LEVEL 5\MOBILE DEVELOPMENT USING FLUTTER\Lecturer_15_jan_practical\lecturer_15_jan"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
