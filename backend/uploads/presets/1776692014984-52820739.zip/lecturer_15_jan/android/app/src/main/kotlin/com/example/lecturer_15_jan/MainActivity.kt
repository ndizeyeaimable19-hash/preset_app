package com.example.lecturer_15_jan

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
