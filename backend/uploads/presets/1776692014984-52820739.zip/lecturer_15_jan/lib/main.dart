import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

/// ROOT WIDGET (START OF WIDGET TREE)
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UI Learning Demo',
      home: HomeScreen(),
    );
  }
}

/// STATEFUL WIDGET (UI CAN CHANGE)
class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String message = "Hello L5 SOD";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("UI Design Demo"),
      ),

      /// COLUMN → VERTICAL LAYOUT
      body: Column(
        children: [

          /// TEXT + STYLING (CORE WIDGET)
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              message,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
            ),
          ),

          /// IMAGE (ASSET)
          Container(
            margin: EdgeInsets.all(10),
            height: 100,
            child: Image.asset('assets/elisa.jpeg'),
          ),

          /// ROW → HORIZONTAL LAYOUT
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.favorite, color: Colors.red),
              SizedBox(width: 10),
              Text("Favorite"),
            ],
          ),

          SizedBox(height: 20),

          /// BUTTON (INTERACTIVE WIDGET)
          ElevatedButton(
            onPressed: () {
              setState(() {
                message = "Button Pressed!";
              });
            },
            child: Text("Press Me"),
          ),

          SizedBox(height: 20),

          /// GESTURE DETECTOR
          GestureDetector(
            onTap: () {
              setState(() {
                message = "Screen Tapped!";
              });
            },
            child: Container(
              padding: EdgeInsets.all(10),
              color: Colors.grey.shade300,
              child: Text("Tap Me"),
            ),
          ),

          SizedBox(height: 20),

          /// EXPANDED + ROW (SPACE SHARING)
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 40,
                  color: Colors.red,
                ),
              ),
              Expanded(
                child: Container(
                  height: 40,
                  color: Colors.green,
                ),
              ),
            ],
          ),

          SizedBox(height: 20),

          /// STACK (OVERLAY)
          Stack(
            children: [
              Container(
                height: 80,
                width: 200,
                color: Colors.lightBlue,
              ),
              Positioned(
                top: 25,
                left: 50,
                child: Text(
                  "Overlay Text",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
